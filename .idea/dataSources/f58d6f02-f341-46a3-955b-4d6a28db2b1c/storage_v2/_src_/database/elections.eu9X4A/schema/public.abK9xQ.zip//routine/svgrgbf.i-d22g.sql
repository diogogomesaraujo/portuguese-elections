create function svgrgbf(red double precision, green double precision, blue double precision) returns text
    immutable
    strict
    language plpgsql
as
$$
BEGIN
  RETURN svgRGB(
    svgClamp(255 * red,   0, 255)::int,
    svgClamp(255 * green, 0, 255)::int,
    svgClamp(255 * blue,  0, 255)::int);
END;
$$;

alter function svgrgbf(double precision, double precision, double precision) owner to rodrigoaraujo;


create function svglineargradient(id text, color1 text, color2 text) returns text
    immutable
    strict
    language plpgsql
as
$$
BEGIN
  RETURN '<linearGradient id="' || id || '" x1="0%" y1="0%" x2="100%" y2="0%">'
    || '<stop offset="0%" style="stop-color:' || color1 || ';stop-opacity:1" />'
    || '<stop offset="100%" style="stop-color:' || color2 || ';stop-opacity:1" />'
    || '</linearGradient>';
END;
$$;

alter function svglineargradient(text, text, text) owner to rodrigoaraujo;


create function svgpolygon(pts double precision[], class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text, title text DEFAULT ''::text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  svg_poly text;
  svg_pts text;
  sep text;
BEGIN

  svg_pts := '';
  FOR i IN 1..array_length( pts, 1 ) LOOP
    sep := CASE i % 2 WHEN 0 THEN ' ' ELSE ',' END;
    svg_pts := svg_pts || pts[i] || sep;
  END LOOP;

  svg_poly := '<polygon '
    || _svgAttr( class, id, style, attr)
    || ' points="' || svg_pts || '" />';

  IF title <> '' THEN
    svg_poly := '<g>' || svg_poly;
    svg_poly := svg_poly || '<title>' || title || '</title></g>';
  END IF;

  RETURN svg_poly;
END;
$$;

alter function svgpolygon(double precision[], text, text, text, text, text) owner to rodrigoaraujo;


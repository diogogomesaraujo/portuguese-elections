create function svgrandint(lo integer, hi integer) returns integer
    strict
    language plpgsql
as
$$
BEGIN
  RETURN floor(random() * (hi - lo + 1) ) + lo;
END;
$$;

alter function svgrandint(integer, integer) owner to rodrigoaraujo;


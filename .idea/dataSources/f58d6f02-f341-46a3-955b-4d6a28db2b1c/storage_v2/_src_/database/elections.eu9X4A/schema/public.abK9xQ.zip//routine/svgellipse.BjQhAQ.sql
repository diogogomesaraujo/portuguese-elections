create function svgellipse(x double precision, y double precision, rx double precision, ry double precision, class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text, title text DEFAULT ''::text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  svg text;
BEGIN
  svg := '<ellipse '
    || _svgAttr( class, id, style, attr)
    || ' cx="' || x || '" cy="' || y
    || '" rx="' || rx || '" ry="' || ry
    || '" />';

  IF title <> '' THEN
    svg := '<g>' || svg;
    svg := svg || '<title>' || title || '</title></g>';
  END IF;

  RETURN svg;
END;
$$;

alter function svgellipse(double precision, double precision, double precision, double precision, text, text, text, text, text) owner to rodrigoaraujo;


create function svgclamp(val double precision, min double precision, max double precision) returns double precision
    immutable
    strict
    language plpgsql
as
$$
BEGIN
  RETURN CASE WHEN val < min THEN min
    WHEN val > max THEN max
    ELSE val
  END;
END;
$$;

alter function svgclamp(double precision, double precision, double precision) owner to rodrigoaraujo;


create function svghsl(hue double precision, saturation double precision DEFAULT 100, lightness double precision DEFAULT 50) returns text
    immutable
    strict
    language plpgsql
as
$$
BEGIN
  RETURN 'hsl(' || hue || ',' || saturation || '%,' || lightness || '%)';
END;
$$;

alter function svghsl(double precision, double precision, double precision) owner to rodrigoaraujo;


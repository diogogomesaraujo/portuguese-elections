create function svgstyleprop(stroke text DEFAULT ''::text, strokewidth text DEFAULT ''::text, fill text DEFAULT ''::text, fillopacity text DEFAULT ''::text, font text DEFAULT ''::text, css text[] DEFAULT ARRAY[]::text[]) returns text
    immutable
    language plpgsql
as
$$
DECLARE
  style text;
BEGIN

  style := '';
  IF stroke <> '' THEN
    style := ' stroke:' || stroke || ';';
  END IF;
  IF strokewidth <> '' THEN
    style :=  style || ' stroke-width:' || strokewidth || ';';
  END IF;
  IF fill <> '' THEN
    style :=  style || ' fill:' || fill || ';';
  END IF;
  IF fillopacity <> '' THEN
    style :=  style || ' fill-opacity:' || fillopacity || ';';
  END IF;
  IF font <> '' THEN
    style :=  style || ' font:' || font || ';';
  END IF;

  IF array_length(css, 1) > 0 THEN
    FOR i IN 1..array_length( css, 1)/2 LOOP
      style := style || ' ' || css[2*i-1] || ':' || css[2*i] || ';';
    END LOOP;
  END IF;

  RETURN style;
END;
$$;

alter function svgstyleprop(text, text, text, text, text, text[]) owner to rodrigoaraujo;


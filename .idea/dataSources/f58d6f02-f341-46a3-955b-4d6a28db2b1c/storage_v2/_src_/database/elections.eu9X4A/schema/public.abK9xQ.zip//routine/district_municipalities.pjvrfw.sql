create function district_municipalities(election_type text, election_year integer, office text, district_name text, party_sigla text, stroke text, strokewidth text, fill text, fillopacity text, precision_value integer) returns text
    stable
    language plpgsql
as
$$
BEGIN
    RETURN map_territory(
        election_type,
        election_year,
        office,
        'municipality',
        district_name,
        NULL,
        party_sigla,
        stroke,
        strokewidth,
        fill,
        fillopacity,
        precision_value
    );
END;
$$;

alter function district_municipalities(text, integer, text, text, text, text, text, text, text, integer) owner to rodrigoaraujo;


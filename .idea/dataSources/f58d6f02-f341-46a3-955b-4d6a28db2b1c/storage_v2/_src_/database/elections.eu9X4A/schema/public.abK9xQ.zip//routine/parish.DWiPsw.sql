create function parish(election_type text, election_year integer, office text, parish_name text, stroke text, strokewidth text, fill text, fillopacity text, precision_value integer) returns text
    stable
    language plpgsql
as
$$
DECLARE
    svg text;
BEGIN
    WITH selected_election AS (
        SELECT
            election_key,
            election_code,
            wh.dim_election.election_type AS election_type,
            wh.dim_election.election_year AS election_year
        FROM wh.dim_election
        WHERE lower(wh.dim_election.election_type) = lower(parish.election_type)
          AND wh.dim_election.election_year = parish.election_year
        LIMIT 1
    ),

    selected_office AS (
        SELECT
            office_key,
            office_code,
            office_name
        FROM wh.dim_office
        WHERE lower(office_code) = lower(parish.office)
           OR lower(office_name) = lower(parish.office)
        LIMIT 1
    ),

    parish_context AS (
        SELECT
            p.territory_key AS parish_key,
            p.territory_code AS parish_code,
            p.territory_name AS parish_name,
            p.parent_code AS municipality_code,
            p.parent_name AS municipality_name,

            m.parent_code AS raw_district_code,
            d.territory_name AS raw_district_name,

            CASE
                WHEN m.parent_code IN ('31', '32') THEN '20'
                WHEN m.parent_code IN ('41', '42', '43', '44', '45', '46', '47', '48', '49') THEN '19'
                ELSE m.parent_code
            END AS legislative_circle_code,

            ST_SimplifyPreserveTopology(
                ST_CollectionExtract(
                    ST_Scale(
                        ST_Transform(p.geom, 4326),
                        10000,
                        10000
                    ),
                    3
                ),
                precision_value
            ) AS geom
        FROM wh.dim_territory p
        LEFT JOIN wh.dim_territory m
          ON m.territory_code = p.parent_code
         AND m.territory_level = 'municipality'
        LEFT JOIN wh.dim_territory d
          ON d.territory_code = m.parent_code
         AND d.territory_level = 'district'
        WHERE p.territory_level = 'parish'
          AND lower(unaccent(p.territory_name)) = lower(unaccent(parish.parish_name))
          AND p.geom IS NOT NULL
    ),

    vote_context AS (
        SELECT
            pc.*,
            se.election_key,
            se.election_type,
            so.office_key,
            so.office_code,

            CASE
                WHEN so.office_code = 'AR'
                  OR se.election_type = 'LEGISLATIVAS'
                THEN pc.legislative_circle_code

                WHEN so.office_code = 'AF'
                THEN pc.parish_code

                WHEN so.office_code IN ('CM', 'AM')
                THEN pc.municipality_code

                WHEN so.office_code IN ('PR', 'PE')
                THEN 'PT'

                ELSE pc.parish_code
            END AS vote_territory_code,

            CASE
                WHEN so.office_code = 'AR'
                  OR se.election_type = 'LEGISLATIVAS'
                THEN 'district'

                WHEN so.office_code = 'AF'
                THEN 'parish'

                WHEN so.office_code IN ('CM', 'AM')
                THEN 'municipality'

                WHEN so.office_code IN ('PR', 'PE')
                THEN 'country'

                ELSE 'parish'
            END AS vote_territory_level
        FROM parish_context pc
        CROSS JOIN selected_election se
        CROSS JOIN selected_office so
    ),

    winner AS (
        SELECT
            vc.parish_code,
            pe.sigla AS winner_sigla,
            pe.color AS winner_color,
            fvr.votes AS winner_votes,
            round(fvr.vote_share * 100, 2) AS winner_pct
        FROM vote_context vc
        JOIN wh.dim_territory vt
          ON vt.territory_code = vc.vote_territory_code
         AND vt.territory_level = vc.vote_territory_level
        JOIN wh.fact_vote_result fvr
          ON fvr.election_key = vc.election_key
         AND fvr.office_key = vc.office_key
         AND fvr.territory_key = vt.territory_key
        JOIN wh.dim_political_entity pe
          ON pe.political_entity_key = fvr.political_entity_key
        WHERE fvr.result_rank = 1
    ),

    parish_geom AS (
        SELECT
            pc.parish_code AS territory_code,
            pc.parish_name AS territory_name,
            pc.municipality_name,
            pc.raw_district_name AS district_name,
            COALESCE(w.winner_sigla, '') AS winner_sigla,
            COALESCE(w.winner_color, fill) AS winner_color,
            w.winner_votes,
            w.winner_pct,
            pc.geom
        FROM parish_context pc
        LEFT JOIN winner w
          ON w.parish_code = pc.parish_code
    )

    SELECT svgdoc(
        content => array_agg(
            svgshape(
                ST_CollectionExtract(geom, 3),
                title =>
                    territory_name
                    || ' / ' || municipality_name
                    || COALESCE(' / ' || district_name, '')
                    || CASE
                        WHEN winner_sigla <> ''
                        THEN ' / Winner: ' || winner_sigla
                           || ' / ' || winner_votes::text || ' votos'
                           || ' / ' || winner_pct::text || '%'
                        ELSE ''
                    END,
                style => svgstyleprop(
                    stroke => stroke::text,
                    strokewidth => strokewidth::text,
                    fill => winner_color::text,
                    fillopacity => fillopacity::text
                )
            )
            ORDER BY territory_code
        ),
        viewbox => svgviewbox(ST_Collect(geom))
    )
    INTO svg
    FROM parish_geom
    WHERE geom IS NOT NULL
      AND NOT ST_IsEmpty(geom);

    RETURN svg;
END;
$$;

alter function parish(text, integer, text, text, text, text, text, text, integer) owner to rodrigoaraujo;


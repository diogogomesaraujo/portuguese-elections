create function svgshape(geom geometry, class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text, title text DEFAULT ''::text, radius double precision DEFAULT 1) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  svg_geom text;
  svg_pts text;
  fillrule text;
  classAttr text;
  idAttr text;
  styleAttr text;
  attrs text;
  pathAttrs text;
  radiusAttr text;
  tag text;
  geom_elem geometry[];
  isGrp boolean;
  gelem geometry;
  outstr text;
BEGIN

 attrs := _svgAttr( class, id, style, attr);
 geom_elem := ARRAY( SELECT (ST_Dump( geom )).geom );

IF cardinality( geom_elem ) = 0 THEN
  RETURN '';
END IF;

 isGrp := array_length( geom_elem,1 ) > 1;
 IF isGrp THEN
   outstr := '<g ' || attrs || '>' || E'\n';
   pathAttrs := '';
 ELSE
   outstr := '';
   pathAttrs := attrs;
 END IF;

 FOR i IN 1..array_length( geom_elem, 1 ) LOOP
   gelem := geom_elem[i];
   svg_pts := ST_AsSVG( gelem );
   tag := 'path';
   radiusAttr := '';
   -- points already have attribute names
   IF ST_Dimension( gelem ) > 0 THEN
     svg_pts := ' d="' || svg_pts || '" ';
   ELSE
     tag := 'circle';
     radiusAttr := ' r="' || radius || '" ';
   END IF;

   CASE ST_Dimension( gelem )
   WHEN 1 THEN fillrule := ' fill="none" ';
   WHEN 2 THEN fillrule := ' fill-rule="evenodd" ';
   ELSE fillrule := '';
   END CASE;

   IF i > 1 THEN
     outstr := outstr || E'\n';
   END IF;

   svg_geom := '<' || tag || ' ' || pathAttrs || fillrule
     || radiusAttr
     || ' ' || svg_pts;
   outstr := outstr || svg_geom;

   IF title <> '' AND NOT isGrp THEN
     outstr := outstr || '><title>' || title || '</title>';
     outstr := outstr || '</' || tag || '>';
   ELSE
     outstr := outstr || ' />';
   END IF;
 END LOOP;

 IF isGrp THEN
   outstr := outstr || E'\n';
   IF title <> '' THEN
     outstr := outstr || '<title>' || title || '</title>';
   END IF;
   outstr := outstr || '</g>';
 END IF;

 RETURN outstr;
END;
$$;

alter function svgshape(geometry, text, text, text, text, text, double precision) owner to rodrigoaraujo;


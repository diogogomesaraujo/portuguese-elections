create function parish(election_type text, election_year integer, office text, parish_name text, party_sigla text, stroke text, strokewidth text, fill text, fillopacity text, precision_value integer) returns text
    stable
    language plpgsql
as
$$
BEGIN
    RETURN map_territory(
        election_type,
        election_year,
        office,
        'parish',
        NULL,
        parish_name,
        party_sigla,
        stroke,
        strokewidth,
        fill,
        fillopacity,
        precision_value
    );
END;
$$;

alter function parish(text, integer, text, text, text, text, text, text, text, integer) owner to rodrigoaraujo;


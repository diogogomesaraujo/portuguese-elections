create function svgviewbox(extent geometry) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  w float8;
  h float8;
  vbData text;
BEGIN
  w = ST_XMax(extent) - ST_XMin(extent);
  h = ST_YMax(extent) - ST_YMin(extent);
  vbData := ST_XMin(extent) || ' ' || -ST_YMax(extent) || ' ' || w || ' ' || h;
  RETURN vbData;
END;
$$;

alter function svgviewbox(geometry) owner to rodrigoaraujo;


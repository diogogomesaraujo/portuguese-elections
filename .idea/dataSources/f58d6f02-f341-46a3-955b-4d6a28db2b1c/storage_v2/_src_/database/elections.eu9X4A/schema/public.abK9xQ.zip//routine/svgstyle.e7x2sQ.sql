create function svgstyle(VARIADIC arr text[]) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  style text;
BEGIN
  style := '';
  FOR i IN 1..array_length( arr, 1)/2 LOOP
    style := style || arr[2*i-1] || ':' || arr[2*i] || '; ';
  END LOOP;
  RETURN style;
END;
$$;

alter function svgstyle(text[]) owner to rodrigoaraujo;


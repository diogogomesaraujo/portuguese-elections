create function svgtext(loc geometry, content text, class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  x float8;
  y float8;
BEGIN
-- TODO: generalize for all geom types (centroid?)
  x := ST_XMin(loc);
  y := -ST_YMin(loc);
  RETURN '<text'
    || ' x="' || x || '" y="' || y || '" '
    || _svgAttr( class, id, style, attr)
    || '>' || content || '</text>';
END;
$$;

alter function svgtext(geometry, text, text, text, text, text) owner to rodrigoaraujo;


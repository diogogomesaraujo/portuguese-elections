create function _svgattr(class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  classAttr text;
  idAttr text;
  styleAttr text;
  attrs text;
BEGIN
  classAttr := '';
  IF class <> '' THEN
    classAttr := ' class="' || class || '"';
  END IF;

  idAttr := '';
  IF id <> '' THEN
    idAttr := ' id="' || id || '"';
  END IF;

  styleAttr := '';
  IF style <> '' THEN
    styleAttr := ' style="' || style || '"';
  END IF;

  attrs := classAttr || idAttr || styleAttr || attr;

  RETURN attrs;
END;
$$;

alter function _svgattr(text, text, text, text) owner to rodrigoaraujo;


create function svgrect(x double precision, y double precision, width double precision, height double precision, rx double precision DEFAULT 0.0, ry double precision DEFAULT 0.0, class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text, title text DEFAULT ''::text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  svg text;
BEGIN
  svg := '<rect '
    || _svgAttr( class, id, style, attr)
    || ' x="' || x || '" y="' || y || '"'
    || CASE WHEN rx = 0.0 THEN '' ELSE ' rx="' || rx || '"' END
    || CASE WHEN ry = 0.0 THEN '' ELSE ' ry="' || ry || '"' END
    || ' width="' || width || '" height="' || height
    || '" />';

  IF title <> '' THEN
    svg := '<g>' || svg;
    svg := svg || '<title>' || title || '</title></g>';
  END IF;

  RETURN svg;
END;
$$;

alter function svgrect(double precision, double precision, double precision, double precision, double precision, double precision, text, text, text, text, text) owner to rodrigoaraujo;


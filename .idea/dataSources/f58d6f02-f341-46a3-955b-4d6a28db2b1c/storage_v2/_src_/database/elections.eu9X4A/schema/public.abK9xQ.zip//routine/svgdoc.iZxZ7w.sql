create function svgdoc(content text[], viewbox text DEFAULT '0 0 100 100'::text, def text DEFAULT ''::text, width integer DEFAULT '-1'::integer, height integer DEFAULT '-1'::integer, style text DEFAULT ''::text) returns text
    immutable
    language plpgsql
as
$$
DECLARE
  viewBoxAttr text;
  styleAttr text;
  widthAttr text;
  heightAttr text;
  svg text;
BEGIN
  viewBoxAttr := ' viewBox="' || viewbox || '" ';

  styleAttr := '';
  IF style <> '' THEN
    styleAttr := ' style="' || style || '" ';
  END IF;

  widthAttr := '';
  IF width >= 0 THEN
    widthAttr := ' width="' || width || '" ';
  END IF;

  heightAttr := '';
  IF height >= 0 THEN
    heightAttr := ' height="' || height || '" ';
  END IF;

  svg := '<svg xmlns="http://www.w3.org/2000/svg"'
    || widthAttr || heightAttr
    || viewBoxAttr || styleAttr  || E'> \n';

  IF def <> '' THEN
    svg := svg || '<defs>' || E'\n';
    svg := svg || def || E'\n';
    svg := svg || '</defs>' || E'\n';
  END IF;

  IF content IS NOT NULL THEN
    FOR i IN 1..array_length( content, 1) LOOP
      svg := svg || content[i] || E'\n';
    END LOOP;
  END IF;

  svg := svg || '</svg>';
  RETURN svg;
END;
$$;

alter function svgdoc(text[], text, text, integer, integer, text) owner to rodrigoaraujo;


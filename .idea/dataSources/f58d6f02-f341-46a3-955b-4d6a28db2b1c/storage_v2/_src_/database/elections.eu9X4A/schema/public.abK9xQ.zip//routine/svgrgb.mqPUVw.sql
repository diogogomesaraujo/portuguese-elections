create function svgrgb(red integer, green integer, blue integer) returns text
    immutable
    strict
    language plpgsql
as
$$
BEGIN
  RETURN 'rgb(' || red || ',' || green || ',' || blue || ')';
END;
$$;

alter function svgrgb(integer, integer, integer) owner to rodrigoaraujo;


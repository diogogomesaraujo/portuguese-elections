create function svgrandpick(VARIADIC pick integer[]) returns integer
    strict
    language plpgsql
as
$$
DECLARE
  i integer;
BEGIN
  i := floor(random() * array_length( pick, 1) ) + 1;
  RETURN pick[i];
END;
$$;

alter function svgrandpick(integer[]) owner to rodrigoaraujo;


create function svggroup(content text[], class text DEFAULT ''::text, id text DEFAULT ''::text, style text DEFAULT ''::text, attr text DEFAULT ''::text, title text DEFAULT ''::text) returns text
    immutable
    strict
    language plpgsql
as
$$
DECLARE
  svg text;
BEGIN
  svg := '<g '
    || _svgAttr( class, id, style, attr)
    || E'> \n';

  IF content IS NOT NULL THEN
    FOR i IN 1..array_length( content, 1) LOOP
      svg := svg || content[i] || E'\n';
    END LOOP;
  END IF;

  svg := svg || '</g>' || E'\n';
  RETURN svg;
END;
$$;

alter function svggroup(text[], text, text, text, text, text) owner to rodrigoaraujo;

